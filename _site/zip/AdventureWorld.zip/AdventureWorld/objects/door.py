class Door(object):

	def __init__(self, button, name, leadsTo):
		self.button = button
		self.name = name
		self.leadsTo = leadsTo