welcomeMessage = "Hello World!"
print(welcomeMessage)