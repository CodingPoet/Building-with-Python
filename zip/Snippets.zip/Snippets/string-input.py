welcomeMessage = raw_input("What is the welcome message?")
print (welcomeMessage)