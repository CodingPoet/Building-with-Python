for number in range(1, 6):
    print(number)