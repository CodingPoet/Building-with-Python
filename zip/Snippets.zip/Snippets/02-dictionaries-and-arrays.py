# dictionaries

playerScores = {
    "Anita": 100,
    "Betsy": 30,
    "Caroline": 75
}

print(playerScores["Betsy"])


# arrays

players = ["Anita", "Betsy", "Caroline"]
scores = [100, 30, 75]

print(players[0])
print(scores[2])