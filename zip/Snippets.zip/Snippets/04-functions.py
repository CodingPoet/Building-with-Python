#plain old function

def sayHello():
    print("Hello!")
    
sayHello()


# function with parameters

def multiplyByTwo(number):
    print(number * 2)
    
multiplyByTwo(2)

