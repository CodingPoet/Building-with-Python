score = 0

if score > 1000:
    print("You won a gold trophy!")
elif score > 800:
    print("You won a silver trophy!")
else:
    print("Sorry, you didn't win any trophy")