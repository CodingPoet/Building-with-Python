class Item(object):

	def __init__(self, button, name):
		self.button = button
		self.name = name